//! Prelude

pub use embedded_hal::prelude::*;
