# How to run

To run the compile tests, use the following command on the root of the project:

```
cargo test --package cortex-m-rt --test compiletest --features device
```
