#[derive(defmt::Format)]
#[defmt(FooBar)]
struct S {
    f: bool,
}

fn main() {}
