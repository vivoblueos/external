fn main() {
    defmt::info!("{=u8:dunno}", 42)
}
