/// The (erased) "Format" type as it appears in `defmt` format strings
pub(crate) const TYPE_FORMAT: &str = "?";
