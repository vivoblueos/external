// see `build.rs` for contents
include!(concat!(env!("OUT_DIR"), "/consts.rs"));
