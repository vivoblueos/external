fn main() {}

#[defmt_test_macros::tests]
mod tests {
    #[after_each]
    #[ignore]
    fn init() {}
}
