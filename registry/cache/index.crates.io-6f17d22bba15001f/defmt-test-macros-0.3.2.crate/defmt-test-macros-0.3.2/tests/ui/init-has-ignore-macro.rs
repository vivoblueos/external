fn main() {}

#[defmt_test_macros::tests]
mod tests {
    #[init]
    #[ignore]
    fn init() {}
}
