fn main() {}

#[defmt_test_macros::tests]
mod tests {
    #[teardown]
    #[ignore]
    fn teardown() {}
}
