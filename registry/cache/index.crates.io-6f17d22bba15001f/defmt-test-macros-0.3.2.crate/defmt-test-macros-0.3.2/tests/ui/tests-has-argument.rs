fn main() {}

#[defmt_test_macros::tests(tests)]
mod tests {
}
