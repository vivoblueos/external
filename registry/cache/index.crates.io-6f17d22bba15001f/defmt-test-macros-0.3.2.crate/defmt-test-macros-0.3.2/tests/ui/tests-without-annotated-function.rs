fn main() {}

#[defmt_test_macros::tests]
mod tests {
    fn some_function() {
    }
}